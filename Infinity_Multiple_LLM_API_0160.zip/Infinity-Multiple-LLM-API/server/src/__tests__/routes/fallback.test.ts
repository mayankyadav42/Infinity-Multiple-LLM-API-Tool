import { describe, it, expect, beforeAll } from 'vitest';
import type { Express } from 'express';
import { createApp } from '../../app.js';
import { getDb, initDb } from '../../db/index.js';
import { encrypt } from '../../lib/crypto.js';
import { recordRateLimitHit } from '../../services/router.js';
import { setCooldown } from '../../services/ratelimit.js';
import { mintDashboardToken, isGatedApiPath } from '../helpers/auth.js';

let dashToken = '';

async function request(app: Express, method: string, path: string, body?: any) {
  const server = app.listen(0, '127.0.0.1');
  if (!server.listening) await new Promise<void>(resolve => server.once('listening', () => resolve()));
  const addr = server.address() as any;
  const url = `http://127.0.0.1:${addr.port}${path}`;

  const res = await fetch(url, {
    method,
    headers: {
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(isGatedApiPath(path) ? { Authorization: `Bearer ${dashToken}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => null);
  server.close();
  return { status: res.status, body: data };
}

describe('Fallback API', () => {
  let app: Express;

  beforeAll(() => {
    process.env.ENCRYPTION_KEY = '0'.repeat(64);
    initDb(':memory:');
    app = createApp();
    dashToken = mintDashboardToken();
  });

  it('GET /api/fallback returns fallback chain', async () => {
    const { status, body } = await request(app, 'GET', '/api/fallback');
    expect(status).toBe(200);
    expect(Array.isArray(body)).toBe(true);
    expect(body.length).toBeGreaterThan(0);
    // Should be sorted by priority
    for (let i = 1; i < body.length; i++) {
      expect(body[i].priority).toBeGreaterThanOrEqual(body[i - 1].priority);
    }
  });

  it('GET /api/fallback entries have expected fields', async () => {
    const { body } = await request(app, 'GET', '/api/fallback');
    const first = body[0];
    expect(first).toHaveProperty('modelDbId');
    expect(first).toHaveProperty('priority');
    expect(first).toHaveProperty('enabled');
    expect(first).toHaveProperty('platform');
    expect(first).toHaveProperty('displayName');
    expect(first).toHaveProperty('intelligenceRank');
    // contextWindow powers the dashboard catalog filter (#343); present even when
    // the catalog has no value for a model (null).
    expect(first).toHaveProperty('contextWindow');
  });

  it('GET /api/fallback/token-usage reports per-model chat usage for configured platforms', async () => {
    const db = getDb();
    const target = db.prepare(`
      SELECT id, platform, model_id FROM models
       WHERE platform = 'groq'
       ORDER BY id LIMIT 1
    `).get() as { id: number; platform: string; model_id: string };
    const other = db.prepare(`
      SELECT platform, model_id FROM models
       WHERE platform <> ?
       LIMIT 1
    `).get(target.platform) as { platform: string; model_id: string };
    const secret = encrypt('usage-test-key');
    db.prepare(`
      INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled)
      VALUES (?, 'usage', ?, ?, ?, 'healthy', 1)
    `).run(target.platform, secret.encrypted, secret.iv, secret.authTag);
    db.prepare(`
      INSERT INTO requests (platform, model_id, key_id, status, input_tokens, output_tokens, latency_ms, error, request_type)
      VALUES (?, ?, NULL, 'success', 123, 45, 10, NULL, 'chat')
    `).run(target.platform, target.model_id);
    db.prepare(`
      INSERT INTO requests (platform, model_id, key_id, status, input_tokens, output_tokens, latency_ms, error, request_type)
      VALUES (?, ?, NULL, 'success', 1000, 1000, 10, NULL, 'chat')
    `).run(other.platform, other.model_id);
    db.prepare(`
      INSERT INTO requests (platform, model_id, key_id, status, input_tokens, output_tokens, latency_ms, error, request_type)
      VALUES (?, ?, NULL, 'success', 500, 500, 10, NULL, 'embedding')
    `).run(target.platform, target.model_id);

    const { status, body } = await request(app, 'GET', '/api/fallback/token-usage');

    expect(status).toBe(200);
    expect(body.totalUsed).toBe(168);
    const model = body.models.find((m: any) => m.modelDbId === target.id);
    expect(model).toMatchObject({
      platform: target.platform,
      modelId: target.model_id,
      used: 168,
    });
  });

  // The budget bar's legend follows this payload's order. Chain priority is
  // seeded provider by provider, so ordering by it read as "grouped by
  // provider" on the dashboard (#1243); the legend wants smartest first.
  it('GET /api/fallback/token-usage lists models smartest first and carries the rank', async () => {
    const db = getDb();
    // Two platforms with keys, several models each, in a deliberately
    // provider-clustered chain order so the old ORDER BY priority would fail.
    const platforms = (db.prepare(`
      SELECT DISTINCT platform FROM models ORDER BY platform LIMIT 2
    `).all() as { platform: string }[]).map(p => p.platform);
    for (const platform of platforms) {
      const secret = encrypt(`order-test-${platform}`);
      db.prepare(`
        INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled)
        VALUES (?, 'order', ?, ?, ?, 'healthy', 1)
      `).run(platform, secret.encrypted, secret.iv, secret.authTag);
    }

    const { status, body } = await request(app, 'GET', '/api/fallback/token-usage');
    expect(status).toBe(200);
    const ranks: number[] = body.models.map((m: any) => m.intelligenceRank);
    expect(ranks.length).toBeGreaterThan(2);
    for (const r of ranks) expect(typeof r).toBe('number');
    expect(ranks).toEqual([...ranks].sort((a, b) => a - b));
    // Not merely coincident with chain order: the models table holds more than
    // one platform here, so a priority-ordered list would interleave differently.
    expect(new Set(body.models.map((m: any) => m.platform)).size).toBeGreaterThan(1);
  });

  // Regression: GET /routing must always carry customWeights, even before the
  // user has saved any — the dashboard's custom-weight sliders dereference it
  // and a missing field white-screened the Fallback page.
  it('GET /api/fallback/routing always includes customWeights', async () => {
    const { status, body } = await request(app, 'GET', '/api/fallback/routing');
    expect(status).toBe(200);
    expect(body).toHaveProperty('strategy');
    expect(body).toHaveProperty('customWeights');
    for (const axis of ['reliability', 'speed', 'intelligence']) {
      expect(typeof body.customWeights[axis]).toBe('number');
    }
  });

  it('GET /api/fallback/penalty-inspector is empty when no model has active pressure', async () => {
    const { status, body } = await request(app, 'GET', '/api/fallback/penalty-inspector');
    expect(status).toBe(200);
    expect(body.lookbackMinutes).toBe(30);
    expect(body.rows).toEqual([]);
  });

  it('GET /api/fallback/penalty-inspector combines penalties, cooldowns and recent errors', async () => {
    const db = getDb();
    const target = db.prepare(`
      SELECT id, platform, model_id, display_name
        FROM models
       WHERE platform = 'groq' AND key_id IS NULL
       ORDER BY id
       LIMIT 1
    `).get() as { id: number; platform: string; model_id: string; display_name: string };
    const secret = encrypt('inspector-test-key');
    const keyId = Number(db.prepare(`
      INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled)
      VALUES (?, 'inspector', ?, ?, ?, 'healthy', 1)
    `).run(target.platform, secret.encrypted, secret.iv, secret.authTag).lastInsertRowid);

    recordRateLimitHit(target.id);
    recordRateLimitHit(target.id);
    setCooldown(target.platform, target.model_id, keyId, 60_000);
    db.prepare(`
      INSERT INTO requests (platform, model_id, key_id, status, latency_ms, error)
      VALUES (?, ?, ?, 'error', 321, 'Groq API error 429: rate limit')
    `).run(target.platform, target.model_id, keyId);

    const { status, body } = await request(app, 'GET', '/api/fallback/penalty-inspector');
    expect(status).toBe(200);
    const row = body.rows.find((r: any) => r.modelDbId === target.id);
    expect(row).toBeDefined();
    expect(row.displayName).toBe(target.display_name);
    expect(row.reasons.sort()).toEqual(['cooldown', 'penalty', 'recent_errors']);
    expect(row.penalty.value).toBeGreaterThan(0);
    expect(row.penalty.hits).toBeGreaterThanOrEqual(2);
    expect(row.penalty.rateLimitFactor).toBeLessThan(1);
    expect(row.cooldowns).toHaveLength(1);
    expect(row.cooldowns[0]).toMatchObject({ keyId, keyLabel: 'inspector', keyStatus: 'healthy' });
    expect(row.cooldowns[0].expiresInMs).toBeGreaterThan(0);
    expect(row.recentErrorCount).toBe(1);
    expect(row.recentErrors[0]).toMatchObject({
      keyId,
      keyLabel: 'inspector',
      latencyMs: 321,
      error: 'Groq API error 429: rate limit',
    });
  });

  it('GET /api/fallback/penalty-inspector includes recent failures even without cooldowns', async () => {
    const db = getDb();
    const target = db.prepare(`
      SELECT id, platform, model_id
        FROM models
       WHERE platform != 'groq'
       ORDER BY id
       LIMIT 1
    `).get() as { id: number; platform: string; model_id: string };
    db.prepare(`
      INSERT INTO requests (platform, model_id, key_id, status, latency_ms, error)
      VALUES (?, ?, NULL, 'error', 111, 'upstream 503 unavailable')
    `).run(target.platform, target.model_id);

    const { status, body } = await request(app, 'GET', '/api/fallback/penalty-inspector');
    expect(status).toBe(200);
    const row = body.rows.find((r: any) => r.modelDbId === target.id);
    expect(row).toBeDefined();
    expect(row.reasons).toEqual(['recent_errors']);
    expect(row.penalty.value).toBe(0);
    expect(row.cooldowns).toEqual([]);
    expect(row.recentErrorCount).toBe(1);
  });

  it('PUT /api/fallback/routing accepts the custom strategy with weights and persists them', async () => {
    const put = await request(app, 'PUT', '/api/fallback/routing', {
      strategy: 'custom',
      weights: { reliability: 50, speed: 30, intelligence: 20 },
    });
    expect(put.status).toBe(200);
    expect(put.body.strategy).toBe('custom');

    // Weights are renormalized to sum 1 and echoed back on the next GET.
    const { body } = await request(app, 'GET', '/api/fallback/routing');
    expect(body.strategy).toBe('custom');
    const w = body.customWeights;
    expect(w.reliability + w.speed + w.intelligence).toBeCloseTo(1, 5);
    expect(w.reliability).toBeCloseTo(0.5, 5);
    expect(w.speed).toBeCloseTo(0.3, 5);

    // Restore a neutral preset so later tests start clean.
    await request(app, 'PUT', '/api/fallback/routing', { strategy: 'balanced' });
  });

  // Regression: the toggle state must ride on GET /routing, not just the PUT
  // echo — the dashboard checkbox renders from the GET payload, so a missing
  // field made it look permanently off and impossible to disable from the UI.
  it('GET /api/fallback/routing reflects the exploration toggle set via PUT', async () => {
    const get0 = await request(app, 'GET', '/api/fallback/routing');
    expect(get0.body.exploreEnabled).toBe(false);

    const put = await request(app, 'PUT', '/api/fallback/routing', {
      strategy: 'balanced',
      exploreEnabled: true,
    });
    expect(put.status).toBe(200);
    expect(put.body.exploreEnabled).toBe(true);

    const get1 = await request(app, 'GET', '/api/fallback/routing');
    expect(get1.body.exploreEnabled).toBe(true);

    // Restore the default so later tests start clean.
    await request(app, 'PUT', '/api/fallback/routing', { strategy: 'balanced', exploreEnabled: false });
    const get2 = await request(app, 'GET', '/api/fallback/routing');
    expect(get2.body.exploreEnabled).toBe(false);
  });

  // Peak-hours adjustment (#760): opt-in, so the stock payload must report it
  // off with the documented window, and the router must still be on the raw
  // preset weights no matter what hour the suite runs at.
  it('GET /api/fallback/routing reports the peak-hours settings, off by default', async () => {
    const { body } = await request(app, 'GET', '/api/fallback/routing');
    expect(body.peakHoursAdjust).toBe(false);
    expect(body.peakStartHour).toBe(18);
    expect(body.peakEndHour).toBe(6);
    expect(body.peakTimezone).toBe('UTC');
    expect(body.peakAdjusted).toBe(false);
    expect(body.weights).toEqual({ reliability: 0.5, speed: 0.25, intelligence: 0.25 });
  });

  it('PUT /api/fallback/routing persists the peak-hours window and echoes the active weights', async () => {
    const put = await request(app, 'PUT', '/api/fallback/routing', {
      strategy: 'balanced',
      peakHoursAdjust: true,
      peakStartHour: 0,
      peakEndHour: 23,
      peakTimezone: 'Asia/Kolkata',
    });
    expect(put.status).toBe(200);
    expect(put.body.peakHoursAdjust).toBe(true);
    expect(put.body.peakStartHour).toBe(0);
    expect(put.body.peakEndHour).toBe(23);
    expect(put.body.peakTimezone).toBe('Asia/Kolkata');
    // 00:00–23:00 covers every hour but the last, so the echo is the adjusted
    // vector except in that one hour — assert the two are consistent with each
    // other rather than pinning the wall clock.
    expect(put.body.weights).toEqual(put.body.peakAdjusted
      ? { reliability: 0.65, speed: 0.1, intelligence: 0.25 }
      : { reliability: 0.5, speed: 0.25, intelligence: 0.25 });
    // The raw preset table is still echoed untouched for older clients.
    expect(put.body.presets.balanced).toEqual({ reliability: 0.5, speed: 0.25, intelligence: 0.25 });

    const { body } = await request(app, 'GET', '/api/fallback/routing');
    expect(body.peakHoursAdjust).toBe(true);
    expect(body.peakTimezone).toBe('Asia/Kolkata');

    await request(app, 'PUT', '/api/fallback/routing', {
      strategy: 'balanced', peakHoursAdjust: false, peakStartHour: 18, peakEndHour: 6, peakTimezone: 'UTC',
    });
  });

  it('PUT /api/fallback/routing rejects invalid peak hours and timezones', async () => {
    for (const payload of [
      { peakStartHour: 24 },
      { peakStartHour: -1 },
      { peakEndHour: 24 },
      { peakEndHour: 6.5 },
      { peakTimezone: 'Not/AZone' },
      { peakTimezone: '' },
    ]) {
      const { status } = await request(app, 'PUT', '/api/fallback/routing', { strategy: 'balanced', ...payload });
      expect(status, JSON.stringify(payload)).toBe(400);
    }
    // Nothing was persisted by any of the rejected requests.
    const { body } = await request(app, 'GET', '/api/fallback/routing');
    expect(body.peakHoursAdjust).toBe(false);
    expect(body.peakStartHour).toBe(18);
    expect(body.peakEndHour).toBe(6);
    expect(body.peakTimezone).toBe('UTC');
  });

  it('PUT /api/fallback/routing rejects all-zero custom weights', async () => {
    const { status } = await request(app, 'PUT', '/api/fallback/routing', {
      strategy: 'custom',
      weights: { reliability: 0, speed: 0, intelligence: 0 },
    });
    expect(status).toBe(400);
    await request(app, 'PUT', '/api/fallback/routing', { strategy: 'balanced' });
  });

  it('PUT /api/fallback updates order', async () => {
    const { body: original } = await request(app, 'GET', '/api/fallback');

    // Reverse the order
    const reversed = original.map((e: any, i: number) => ({
      modelDbId: e.modelDbId,
      priority: original.length - i,
      enabled: e.enabled,
    }));

    const { status } = await request(app, 'PUT', '/api/fallback', reversed);
    expect(status).toBe(200);

    // Verify order changed
    const { body: after } = await request(app, 'GET', '/api/fallback');
    expect(after[0].modelDbId).toBe(original[original.length - 1].modelDbId);

    // Restore original order
    const restore = original.map((e: any, i: number) => ({
      modelDbId: e.modelDbId,
      priority: i + 1,
      enabled: e.enabled,
    }));
    await request(app, 'PUT', '/api/fallback', restore);
  });

  it('POST /api/fallback/sort/intelligence sorts by cross-provider tier, then rank', async () => {
    const { status } = await request(app, 'POST', '/api/fallback/sort/intelligence');
    expect(status).toBe(200);

    const { body } = await request(app, 'GET', '/api/fallback');

    // intelligence_rank is per-provider, so the sort normalizes on the
    // cross-provider capability tier (size_label) first (issue #135).
    const tier: Record<string, number> = { Frontier: 1, Large: 2, Medium: 3, Small: 4 };
    const tierOf = (label: string) => tier[label] ?? 5;

    for (let i = 1; i < body.length; i++) {
      const prevTier = tierOf(body[i - 1].sizeLabel);
      const curTier = tierOf(body[i].sizeLabel);
      // Capability tier never decreases...
      expect(curTier).toBeGreaterThanOrEqual(prevTier);
      // ...and within the same tier, per-provider rank breaks the tie.
      if (curTier === prevTier) {
        expect(body[i].intelligenceRank).toBeGreaterThanOrEqual(body[i - 1].intelligenceRank);
      }
    }
  });

  it('budget sort does not rank a rate-limit label above a real monthly budget', async () => {
    // "free · 40 RPM" is a rate limit, not a 40M-token budget: the old
    // per-route parser saw the 'M' in "RPM" and multiplied by 1e6, sorting
    // the model to the top of the chain ahead of genuine ~25M budgets.
    const { body: chain } = await request(app, 'GET', '/api/fallback');
    const [rpmModel, bigModel, smallModel] = chain;
    const db = getDb();
    const orig = [rpmModel, bigModel, smallModel].map((m: any) =>
      db.prepare('SELECT monthly_token_budget, tpd_limit FROM models WHERE id = ?').get(m.modelDbId) as any);

    try {
      db.prepare('UPDATE models SET tpd_limit = NULL, monthly_token_budget = ? WHERE id = ?')
        .run('free · 40 RPM', rpmModel.modelDbId);
      db.prepare('UPDATE models SET tpd_limit = NULL, monthly_token_budget = ? WHERE id = ?')
        .run('~25M', bigModel.modelDbId);
      db.prepare('UPDATE models SET tpd_limit = NULL, monthly_token_budget = ? WHERE id = ?')
        .run('~500K', smallModel.modelDbId);

      const { status } = await request(app, 'POST', '/api/fallback/sort/budget');
      expect(status).toBe(200);

      // Read priorities from the table the route writes for the active
      // profile (the seeded DB has a default profile; fallback_config is the
      // no-profile path). GET /api/fallback re-orders by intelligence rank,
      // so it can't verify the priority the sort wrote.
      const profileId = (db.prepare("SELECT value FROM settings WHERE key = 'active_profile_id'").get() as any)?.value;
      const prio = (id: number) => Number(((profileId
        ? db.prepare('SELECT priority FROM profile_models WHERE profile_id = ? AND model_db_id = ?').get(profileId, id)
        : db.prepare('SELECT priority FROM fallback_config WHERE model_db_id = ?').get(id)
      ) as any).priority);
      // A rate-limit label is "no budget info" (0): the real ~25M budget must
      // sort first, and even a small ~500K budget beats the inflated label.
      // With the old parser the RPM label scored 40M and took priority 1.
      expect(prio(bigModel.modelDbId)).toBeLessThan(prio(rpmModel.modelDbId));
      expect(prio(smallModel.modelDbId)).toBeLessThan(prio(rpmModel.modelDbId));
      expect(prio(bigModel.modelDbId)).toBeLessThan(prio(smallModel.modelDbId));
    } finally {
      const restore = db.prepare('UPDATE models SET monthly_token_budget = ?, tpd_limit = ? WHERE id = ?');
      [rpmModel, bigModel, smallModel].forEach((m: any, i: number) =>
        restore.run(orig[i].monthly_token_budget, orig[i].tpd_limit, m.modelDbId));
    }
  });

  it('intelligence sort never places a weaker tier above a Frontier model (#135)', async () => {
    await request(app, 'POST', '/api/fallback/sort/intelligence');
    const { body } = await request(app, 'GET', '/api/fallback');

    // The last Frontier model must come before the first non-Frontier model —
    // i.e. no "Intel #1 from a weaker provider" leaks above the frontier tier.
    const lastFrontier = body.map((m: any) => m.sizeLabel).lastIndexOf('Frontier');
    const firstNonFrontier = body.findIndex((m: any) => m.sizeLabel !== 'Frontier');
    if (lastFrontier !== -1 && firstNonFrontier !== -1) {
      expect(lastFrontier).toBeLessThan(firstNonFrontier);
    }
  });

  it('POST /api/fallback/sort/speed sorts by speed', async () => {
    const { status } = await request(app, 'POST', '/api/fallback/sort/speed');
    expect(status).toBe(200);

    const { body } = await request(app, 'GET', '/api/fallback');
    // Should be sorted ascending by speed rank
    for (let i = 1; i < body.length; i++) {
      expect(body[i].speedRank).toBeGreaterThanOrEqual(body[i - 1].speedRank);
    }
  });

  it('POST /api/fallback/sort/invalid returns 400', async () => {
    const { status } = await request(app, 'POST', '/api/fallback/sort/invalid');
    expect(status).toBe(400);
  });

  it('POST /api/fallback/sort/constructor returns 400, not 500', async () => {
    // Inherited Object members (`constructor`, `toString`, …) are truthy, so
    // a bare `SORT_PRESETS[preset]` read used to pass the whitelist guard and
    // crash `prepare()` when the function object got interpolated into SQL.
    const { status } = await request(app, 'POST', '/api/fallback/sort/constructor');
    expect(status).toBe(400);
    const { status: tsStatus } = await request(app, 'POST', '/api/fallback/sort/toString');
    expect(tsStatus).toBe(400);
  });
});
