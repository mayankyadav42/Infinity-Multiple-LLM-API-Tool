import { describe, it, expect, vi, afterEach } from 'vitest';
import { resolveProvider } from '../../providers/index.js';
import { CloudflareProvider } from '../../providers/cloudflare.js';

// Regression guard for the 2026-07-11 live-sweep finding: platforms hosting
// hidden-reasoning or buffered non-streaming models (zhipu glm-4.7-flash 41s
// TTFB, agnes-2.0-flash 20s, OpenRouter/OpenCode/Mistral long generations,
// @cf/zai-org/glm-4.7-flash repeated 15s aborts) need a chat timeout above
// 15s or every attempt — streaming included — is aborted before the first byte.
// The value is a private construction detail, so the
// registry entries are asserted via the stored field and Cloudflare via the
// setTimeout the abort rides on.

describe('reasoning-model chat timeouts', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it.each([
    ['mistral', 60_000],
    ['openrouter', 60_000],
    ['zhipu', 60_000],
    ['agnes', 60_000],
    ['opencode', 60_000],
    ['experiential', 60_000],
    ['electronhub', 90_000],
    ['ollama', 120_000], // pre-existing bump; keep it from regressing too
    // Radeon Cloud documents a ten-minute non-streaming and stream-gap limit.
    ['radeon', 600_000],
    // NVIDIA NIM prefills 100k-token prompts for minutes before the first SSE
    // byte; this value doubles as the streaming first-byte grace budget (#584).
    ['nvidia', 180_000],
  ] as const)('%s is registered with a %dms chat timeout', (platform, ms) => {
    const provider = resolveProvider(platform);
    expect(provider).toBeDefined();
    expect((provider as unknown as { timeoutMs: number }).timeoutMs).toBe(ms);
  });

  it('cloudflare GLM 4.7 Flash gets its live-verified 200s per-model timeout', async () => {
    const provider = new CloudflareProvider();
    const delays: number[] = [];
    const origSetTimeout = global.setTimeout;
    vi.spyOn(global, 'setTimeout').mockImplementation(((fn: () => void, ms?: number) => {
      delays.push(ms ?? 0);
      return origSetTimeout(fn, ms);
    }) as typeof setTimeout);
    vi.spyOn(global, 'fetch').mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({
        id: 'chatcmpl-cf', object: 'chat.completion', created: 1,
        model: '@cf/zai-org/glm-4.7-flash',
        choices: [{ index: 0, message: { role: 'assistant', content: 'ok' }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
      }),
      headers: new Headers(),
    } as unknown as Response);

    await provider.chatCompletion(
      'acct:token',
      [{ role: 'user', content: 'hi' }],
      '@cf/zai-org/glm-4.7-flash',
    );

    expect(delays).toContain(200_000);
    expect(delays).not.toContain(15_000);
  });
});
